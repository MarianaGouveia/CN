package cn2122tfclient;

import cn2122tf.*;
import com.google.protobuf.ByteString;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class ClientApp {

    private static int svcPort = 8000;
    private static ManagedChannel channel;
    private static CN2122TFServiceGrpc.CN2122TFServiceStub noBlockStub;

    public static void main(String[] args) throws IOException, InterruptedException {
        if(args.length > 0) {
            svcPort = Integer.parseInt(args[0]);
        }

        loadMenu();

        Scanner sc = new Scanner(System.in);
        sc.next();

    }

    static void setupServerConnection(String svcIP, Integer svcPort) {
        channel = ManagedChannelBuilder.forAddress(svcIP, svcPort)
                .usePlaintext()
                .build();

        noBlockStub = CN2122TFServiceGrpc.newStub(channel);
    }

    static int Menu() {
        Scanner scan = new Scanner(System.in);
        int option;
        do {
            System.out.println("######## MENU ##########");
            System.out.println("Options for Google Storage Operations:");
            System.out.println(" 1: Detect Objects In Image");
            System.out.println(" 2: Get Objects In Image");
            System.out.println(" 3: Get Processed Image");
            System.out.println(" 4: Get Images with Object");
            System.out.println("99: Exit");
            System.out.print("Enter an Option: ");
            option = scan.nextInt();
        } while (!((option >= 0 && option <= 4) || option == 99));
        return option;
    }

    static void loadMenu() throws IOException, InterruptedException {
        boolean end = false;
        Scanner sc = new Scanner(System.in);
        System.out.println("Searching for available servers...");
        String[] serversIP = getAvailableServers();
        String serverIP = "";
        if(serversIP != null && serversIP.length > 0) {
            serverIP = selectAvailableServer(serversIP);
            serverIP = serverIP.equals("") ? "localhost" : serverIP;
        } else {
            serverIP = "localhost";
        }
        System.out.println("Server IP selected: " + serverIP);

        setupServerConnection(serverIP, svcPort);
        while (!end) {
            try {
                int option = Menu();
                switch (option) {
                    case 1:

                        System.out.println();
                        System.out.println("Insert image path");
                        String imagePath = sc.next();
                        detectObjects(imagePath);
                        System.out.println();
                        break;
                    case 2:

                        System.out.println();
                        System.out.println("Insert image name");
                        String imageName = sc.next();
                        getImageObjects(imageName);
                        System.out.println();
                        break;
                    case 3:

                        System.out.println();
                        System.out.println("Insert image name: ");
                        String nameImage = sc.next();
                        System.out.println("Insert image download path: ");
                        String destinationPath = sc.next();
                        getProcessedImage(nameImage, destinationPath);
                        System.out.println();
                        break;
                    case 4:

                        System.out.println();
                        System.out.println("Insert object name: ");
                        String objectName = sc.next();
                        Double confidence = -1.0;
                        confidence = verifyConfidence(sc, confidence);


                        System.out.println("Next insert the time period in which shall be searched the object <"+objectName+">");
                        System.out.println("Insert lower date limit in format -> dd/MM/yyyy: ");
                        String lowerDate = sc.next();
                        System.out.println("Insert upper date limit in format -> dd/MM/yyyy: ");
                        String upperDate = sc.next();
                        getImagesWithObject(objectName, confidence, lowerDate, upperDate);
                        System.out.println();
                        break;
                    case 99:
                        System.exit(0);
                }
            } catch (Exception ex) {
                System.out.println("Error executing operations!");
                ex.printStackTrace();
            }
        }
    }

    private static String selectAvailableServer(String[] serversIP) {
        int rnd = new Random().nextInt(serversIP.length);
        return serversIP[rnd];
    }


    private static String[] getAvailableServers() throws IOException, InterruptedException {
        String cfURL="https://europe-west1-cn2122-t2-g08.cloudfunctions.net/funcLookup?";
        cfURL += "projectid=cn2122-t2-g08&";
        cfURL += "europe-west1-b&";
        cfURL += "instance-group-servers";


        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(cfURL))
                .GET()
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode() == 200) {
            System.out.println(response.body());
            String[] serversIP = response.body().split(",");
            return serversIP;
        } else {
            System.out.println("["+response.statusCode()+"] There was a problem! Server's IP couldn't be accessed");
        }
        return null;
    }

    private static void detectObjects(String imagePath) throws IOException {
        StreamObserver<ImageUploadRequest> streamObserver = noBlockStub.detectObjects(new ClientStreamObserverDetectObjects(imagePath));

        // upload file as chunk
        Path path = Paths.get(imagePath);
        String filename = String.valueOf(path.getFileName());
        String[] filenameParts = filename.split("\\.");
        String basename = filenameParts[0];
        String extension = filenameParts[1];
        InputStream inputStream = Files.newInputStream(path);
        byte[] bytes = new byte[4096];
        int size;
        while ((size = inputStream.read(bytes)) > 0){
            ImageUploadRequest uploadRequest = ImageUploadRequest.newBuilder()
                    .setImage(Image.newBuilder()
                            .setContent(ByteString.copyFrom(bytes, 0 , size))
                            .setMetadata(Metadata.newBuilder()
                                    .setName(basename)
                                    .setType(extension)
                                    .build())
                            .build())
                    .build();
            streamObserver.onNext(uploadRequest);
        }

        // close the stream
        inputStream.close();
        streamObserver.onCompleted();
    }

    private static void getImageObjects(String imageName) {
        ImageObjectsRequest request = ImageObjectsRequest.newBuilder()
                        .setName(imageName)
                .build();

        noBlockStub.getImageObjects(request, new ClientStreamObserverGetImageObjects(imageName));
    }

    private static void getProcessedImage(String imageName, String destinationPath) {
        ImageProcessedRequest request = ImageProcessedRequest.newBuilder()
                .setName(imageName)
                .build();

        noBlockStub.getImageProcessed(request, new ClientStreamObserverGetProcessedImage(destinationPath));
    }

    private static void getImagesWithObject(String objectName, Double minimumConfidence, String lowerDate, String upperDate) {
        ImagesWithObjectRequest request = ImagesWithObjectRequest.newBuilder()
                .setObjectName(objectName.substring(0, 1).toUpperCase() + objectName.substring(1))
                .setConfidence(minimumConfidence)
                .setLowerDate(lowerDate)
                .setUpperDate(upperDate)
                .build();

        noBlockStub.getImagesWithObject(request, new ClientStreamObserverGetImagesWithObject(objectName, minimumConfidence, lowerDate, upperDate));
    }

    private static Double verifyConfidence(Scanner sc, Double confidence) {
        boolean number = false;
        while(!number) {
            System.out.println("Insert the minimum confidence of the object presence in image [0-1]: ");
            try {
                confidence = Double.valueOf(sc.next());
                if(confidence <= 1.0f && confidence >= 0.0f) {
                    number = true;
                }
            } catch (Exception e) {

            }

        }
        return Math.abs(confidence);
    }

}
