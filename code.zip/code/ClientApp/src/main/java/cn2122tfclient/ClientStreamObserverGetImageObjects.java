package cn2122tfclient;

import cn2122tf.ImageObject;
import cn2122tf.ImageObjectsResponse;
import io.grpc.stub.StreamObserver;

public class ClientStreamObserverGetImageObjects implements StreamObserver<ImageObjectsResponse> {

    private String imageName;

    public ClientStreamObserverGetImageObjects(String imageName) {
        this.imageName = imageName;
    }


    @Override
    public void onNext(ImageObjectsResponse imageObjectsResponse) {
        System.out.println();
        if(imageObjectsResponse.getImageObjectList().size() == 0) {
            System.out.println("No objects in image <"+this.imageName+">");
            return;
        }
        System.out.println();
        System.out.println("Objects in image <"+this.imageName+">:");
        System.out.println("--------------------------------------");
        for (ImageObject imageObject : imageObjectsResponse.getImageObjectList()) {

            System.out.println("Object: " + imageObject.getName() + " | Confidence: " + imageObject.getConfidence());
        }
    }

    @Override
    public void onError(Throwable throwable) {
        System.out.println();
        System.err.println("An Error Ocurred! Couldn't identify objects of image <"+ this.imageName +">.");
    }

    @Override
    public void onCompleted() {
        System.out.println("Done");
    }

}
