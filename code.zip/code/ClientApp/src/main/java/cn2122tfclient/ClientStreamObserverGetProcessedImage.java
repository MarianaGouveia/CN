package cn2122tfclient;



import cn2122tf.ImageProcessedResponse;
import cn2122tf.Metadata;
import io.grpc.stub.StreamObserver;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;


public class ClientStreamObserverGetProcessedImage implements StreamObserver<ImageProcessedResponse> {

    ByteArrayOutputStream writer;
    String filename;
    String fileType;
    String destinationPath;

    public ClientStreamObserverGetProcessedImage(String destinationPath) {
        this.filename = "";
        this.fileType = "jpg";
        this.destinationPath = destinationPath;
        this.writer = new ByteArrayOutputStream();
    }


    @Override
    public void onNext(ImageProcessedResponse imageProcessedResponse) {
        try {
            if(imageProcessedResponse.getImage().hasMetadata()) {
                setMetadata(imageProcessedResponse.getImage().getMetadata());
            }
            writer.write(imageProcessedResponse.getImage().getContent().toByteArray());
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onError(Throwable throwable) {
        System.out.println();
        System.err.println("An Error Ocurred! The processed image <"+this.filename+"> couldn't be accessed.");
    }

    @Override
    public void onCompleted() {
        try {
            saveProcessedImage();
            writer.close();

        } catch ( Exception  e) {
            e.printStackTrace();
        }
        System.out.println();
        System.out.println("Image <"+this.filename+'.'+this.fileType+"> downloaded to <"+this.destinationPath+">");
        System.out.println("Done");
    }

    private void setMetadata(Metadata metadata) {

        this.filename = metadata.getName();
        this.fileType = metadata.getType();
    }

    private void saveProcessedImage() throws IOException {
        Path path = Paths.get(destinationPath + "\\" + filename + "." + fileType);
        File imageFile = path.toFile();

        InputStream is = new ByteArrayInputStream(writer.toByteArray());
        BufferedImage image = ImageIO.read(is);

        ImageIO.write(image, fileType, imageFile);
        if (imageFile.createNewFile()) {
            System.out.println();
            System.out.println("File not created: " + imageFile.getName());
        } else {
            System.out.println();
            System.out.println("File created successfully.");
        }
    }
}
