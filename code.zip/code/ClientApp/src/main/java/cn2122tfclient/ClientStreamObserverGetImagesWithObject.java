package cn2122tfclient;



import cn2122tf.*;
import io.grpc.stub.StreamObserver;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;


public class ClientStreamObserverGetImagesWithObject implements StreamObserver<ImagesWithObjectResponse> {


    private String lowerDate;
    private String upperDate;
    private double confidence;
    private String objectName;

    public ClientStreamObserverGetImagesWithObject(String objectName, double confidence, String lowerDate, String upperDate) {
        this.objectName = objectName;
        this.confidence = confidence;
        this.lowerDate = lowerDate;
        this.upperDate = upperDate;
    }

    @Override
    public void onNext(ImagesWithObjectResponse imagesWithObjectResponse) {
        if(imagesWithObjectResponse.getImageNameList().size() == 0) {
            System.out.println();
            System.out.println("No images found that have object <"+ objectName +"> with confidence greater than <"
                    +this.confidence+"> between dates <"
                    +this.lowerDate+" - "
                    +this.upperDate+">");
            return;
        }
        System.out.println();
        System.out.println("-----------------------------------------");
        System.out.println("Images with object <"+ objectName +"> with confidence greater than <"
                +this.confidence+"> between dates <"
                +this.lowerDate+" - "
                +this.upperDate+">:");
        System.out.println("-----------------------------------------");
        for (String imageName : imagesWithObjectResponse.getImageNameList()) {

            System.out.println("Image: " + imageName);
        }
    }

    @Override
    public void onError(Throwable throwable) {
        System.out.println();
        System.err.println("An Error Ocurred! Invalid query parameters for object <"+ this.objectName +">.");
    }

    @Override
    public void onCompleted() {
        System.out.println("-----------------------------------------");
        System.out.println("Done");
    }
}
