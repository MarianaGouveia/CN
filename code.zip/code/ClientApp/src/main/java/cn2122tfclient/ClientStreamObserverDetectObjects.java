package cn2122tfclient;

import cn2122tf.ImageUploadResponse;
import io.grpc.stub.StreamObserver;

public class ClientStreamObserverDetectObjects implements StreamObserver<ImageUploadResponse> {

    private String imageName;

    public ClientStreamObserverDetectObjects(String imageName) {
        this.imageName = imageName;
    }

    @Override
    public void onNext(ImageUploadResponse imageUploadResponse) {
        System.out.println();
        System.out.println("Image identifier: " + imageUploadResponse.getName());
    }

    @Override
    public void onError(Throwable throwable) {
        System.out.println();
        System.err.println("An Error Ocurred! Couldn't detect objects of image <"+ this.imageName +">.");
    }

    @Override
    public void onCompleted() {
        System.out.println("Done");
    }

}
