Depois de gerar o JAR, executar o servidor da seguinte forma:

java -jar target/CN2122TFClientApp-1.0-jar-with-dependencies.jar 8000

8000 -> porto do servidor gRPC

-----------------------------------------------

Nota: Atualmente os parâmetros do pedido HTTP feito ao Lookup Function estão "hardcoded" na função getAvailableServers() da classe ClientApp.
Para que funcione com outro projeto e outro instance group, é preciso alterar o pedido presente nessa função.