package cn2122tf;


import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class FireStoreOperations {

    Firestore db;
    String currentCollection;

    public void init(String pathFileKeyJson) throws IOException {
        GoogleCredentials credentials = null;
        if (pathFileKeyJson != null) {
            InputStream serviceAccount = new FileInputStream(pathFileKeyJson);
            credentials = GoogleCredentials.fromStream(serviceAccount);
        } else {
            // use GOOGLE_APPLICATION_CREDENTIALS environment variable
            credentials = GoogleCredentials.getApplicationDefault();
        }
        FirestoreOptions options = FirestoreOptions
                .newBuilder().setCredentials(credentials).build();
        db = options.getService();
        currentCollection = "Images";
    }

    public void close() throws Exception {
        db.close();
    }

    public List<HashMap<String, Object>> getObjectsInImage(String blobName) throws Exception {
        // Single query
        Query query = db.collection(currentCollection).document(blobName).collection("objects");
        // retrieve  query results asynchronously using query.get()
        ApiFuture<QuerySnapshot> querySnapshot = query.get();

        List<HashMap<String, Object>> objects = new ArrayList<HashMap<String, Object>>();

        for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {
            HashMap<String, Object> map = new HashMap<String, Object>() {
                {
                    put("name", doc.get("name") );
                    put("confidence", doc.get("confidence"));
                }
            };

            objects.add(map);

        }
        return objects;

    }

    private List<String> getImagesByDateRange(String lowerDateStr, String upperDateStr, List<String> imagesWithObj) throws Exception {

        List<String> blobNames = new ArrayList<String>();
        System.out.println("Entrei Date");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setTimeZone(TimeZone.getTimeZone("Europe/London"));
        Date lowerDate = null;
        Date upperDate = null;

        lowerDate = sdf.parse(lowerDateStr);
        upperDate = sdf.parse(upperDateStr);


        // Single query
        Query query = db.collection("Images").whereIn(FieldPath.documentId(), imagesWithObj);
        // retrieve  query results asynchronously using query.get()
        ApiFuture<QuerySnapshot> querySnapshot = query.get();

        for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {

            Date blobDate = doc.getDate("date");

            if (blobDate != null && blobDate.before(lowerDate) && blobDate.after(upperDate)) {
                System.out.println("Date - BlobName: " + doc.getId());
                blobNames.add(doc.getId());
            }

        }
        return blobNames;
    }

    private List<String> getImagesByObjectNameConf(String objName, double confidence) throws Exception {

        List<String> blobNames = new ArrayList<>();

        System.out.println("Entrei Object Name Conf");
        // Single query
        Query query = db.collectionGroup("objects").whereEqualTo("name", objName)
                .whereGreaterThanOrEqualTo("confidence", confidence);
        // retrieve  query results asynchronously using query.get()
        ApiFuture<QuerySnapshot> querySnapshot = query.get();

        for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {
            //System.out.println(doc.getId());
            String blobId = doc.getReference().getParent().getParent().getId();
            System.out.println(blobId);

            if(!blobNames.contains(blobId)){
                blobNames.add(blobId);
            }
        }

        return blobNames;
    }

    public List<String> getImagesByDateRangeNameConf(String objName, double confidence, String lowerDate, String upperDate) throws Exception {


        List<String> nameConfBlobNames = getImagesByObjectNameConf(objName, confidence);

        if(nameConfBlobNames.size() == 0) {
            System.out.println("No images found that have object <"+ objName +"> with confidence greater than <"
                    +confidence+"> between dates <"
                    +lowerDate+" - "
                    +upperDate+">");
            return nameConfBlobNames;
        }
        List<String> dateBlobNames = getImagesByDateRange(upperDate, lowerDate, nameConfBlobNames);

        for(String blobname : dateBlobNames){
            System.out.println("Blobs: " + blobname);
        }

        return dateBlobNames;
    }

}
