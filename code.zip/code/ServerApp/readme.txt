Para que o servidor funcione, é necessário utilizar uma conta de serviço Google com as seguintes permissões:
- Cloud Datastore Owner
- Pub/Sub Admin
- Storage Admin

Para correr o servidor, executar os seguintes comandos:

set GOOGLE_APPLICATION_CREDENTIALS=<conta de serviço>
java -jar CN2122TFServiceImpl-1.0-jar-with-dependencies.jar 8000 <nome do bucket>

8000 -> porto do servidor

----------------------------------------------------

Nota: Garantir que o nome do bucket inserido no servidor é o mesmo do bucket inserido no worker