#! /bin/bash
export GOOGLE_APPLICATION_CREDENTIALS=cn2122-t2-g08-6e4d6484ca47.json
java -jar CN2122TFServiceImpl-1.0-jar-with-dependencies.jar 8000
