package googlepubsub;

import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;
import com.google.cloud.functions.BackgroundFunction;
import com.google.cloud.functions.Context;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.logging.Logger;

public class Entrypoint  implements BackgroundFunction<PSmessage> {
    private static final Logger logger = Logger.getLogger(Entrypoint.class.getName());

    private static Firestore initFirestore() {
        try {
            GoogleCredentials credentials = GoogleCredentials.getApplicationDefault();
            FirestoreOptions options = FirestoreOptions.newBuilder().setCredentials(credentials).build();
            Firestore db = options.getService();
            return db;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void accept(PSmessage message, Context context) throws Exception {
        logger.info("original message " + message.data);
        String data = new String(Base64.getDecoder().decode(message.data));
        logger.info(data);
        try {
            MonitorTask.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("Event was written to Firestore.");
    }


}
