package googlepubsub;

import java.util.Map;

public class PSmessage {
    String data;
    Map<String, String> attributes;
}
