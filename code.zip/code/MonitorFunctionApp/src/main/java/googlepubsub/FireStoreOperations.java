package googlepubsub;


import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class FireStoreOperations {

    Firestore db;
    String currentCollection;

    public void init(String pathFileKeyJson, String collectionName) throws IOException {
        GoogleCredentials credentials = null;
        if (pathFileKeyJson != null) {
            InputStream serviceAccount = new FileInputStream(pathFileKeyJson);
            credentials = GoogleCredentials.fromStream(serviceAccount);
        } else {
            // use GOOGLE_APPLICATION_CREDENTIALS environment variable
            credentials = GoogleCredentials.getApplicationDefault();
        }
        FirestoreOptions options = FirestoreOptions
                .newBuilder().setCredentials(credentials).build();
        db = options.getService();
        currentCollection=collectionName;
    }

    public void init(String pathFileKeyJson) throws IOException {
        GoogleCredentials credentials = null;
        if (pathFileKeyJson != null) {
            InputStream serviceAccount = new FileInputStream(pathFileKeyJson);
            credentials = GoogleCredentials.fromStream(serviceAccount);
        } else {
            // use GOOGLE_APPLICATION_CREDENTIALS environment variable
            credentials = GoogleCredentials.getApplicationDefault();
        }
        FirestoreOptions options = FirestoreOptions
                .newBuilder().setCredentials(credentials).build();
        db = options.getService();
    }

    public void close() throws Exception {
        db.close();
    }

    public Map<String, Object> readMonitorLog(String collectionID, String documentID) throws Exception {
        DocumentReference docRef = db.collection(collectionID).document(documentID);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        DocumentSnapshot document = future.get();
        if (document.exists()) {
            System.out.println(document.getData().toString());
            return document.getData();
        } else  {
            System.out.println("Document not exists");
        }
        return null;
    }

    public void createMonitorLog(String collectionID, String documentID) throws Exception {
        CollectionReference colRef = db.collection(collectionID);
        DocumentReference docRef = colRef.document(documentID);
        HashMap<String, Object> map = new HashMap<String, Object>() {
            {
                put("numRequests", 1);
                put("numWorkers", 1);
                put("minWorkers", 1);
                put("maxWorkers", 3);
                put("lastCheck", System.currentTimeMillis());
            }
        };
        ApiFuture<WriteResult> future = docRef.create(map); //Create new document
        WriteResult result = future.get();
        //System.out.println("Write result: " + result);
    }

    public void updateMonitorLog(String collectionID, String documentID, long lastCheck, int numWorkers, int numRequests) throws Exception {
        CollectionReference colRef = db.collection(collectionID);
        DocumentReference docRef = colRef.document(documentID);
        HashMap<String, Object> map = new HashMap<String, Object>() {
            {
                put("numRequests", numRequests);
                put("numWorkers", numWorkers);
                put("lastCheck", lastCheck);
            }
        };
        ApiFuture<WriteResult> future = docRef.update(map);
        WriteResult result = future.get();
        //System.out.println("Write result: " + result);
    }

}
