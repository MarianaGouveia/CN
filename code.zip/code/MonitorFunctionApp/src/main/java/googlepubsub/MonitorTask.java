package googlepubsub;

import com.google.api.gax.longrunning.OperationFuture;
import com.google.cloud.compute.v1.InstanceGroupManagersClient;
import com.google.cloud.compute.v1.Operation;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class MonitorTask {

    static final float REF = 0.05f;
    static final float THRESHOLD = 0.02f;
    static final int MONITOR_PERIOD = 60;
    static final String COLLECTION_ID = "Monitor";
    static final String DOCUMENT_ID = "MonitorLog";

    public static void execute() throws Exception {
        FireStoreOperations fsOP = new FireStoreOperations();
        fsOP.init(null);
        monitor(fsOP);
        fsOP.close();
    }

    private static void monitor(FireStoreOperations fsOP) throws Exception {
        HashMap<String, Object> log = (HashMap<String, Object>) fsOP.readMonitorLog(COLLECTION_ID, DOCUMENT_ID);

        // If there are no logs yet, create a first one
        if(log == null) {
            System.out.println("Creating first log: ");
            fsOP.createMonitorLog(COLLECTION_ID, DOCUMENT_ID);
            HashMap<String, Object> firstLog = (HashMap<String, Object>) fsOP.readMonitorLog(COLLECTION_ID, DOCUMENT_ID);
            int num_workers = (int)(long) firstLog.get("numWorkers");
            adaptVMs(num_workers);
            System.out.println("Number of Workers running: " + num_workers + " Workers");
            return;
        }



        long currentLog = System.currentTimeMillis();
        long lastCheck = (long) log.get("lastCheck");

        int numRequests = (int)(long) log.get("numRequests");
        int max_workers = (int)(long) log.get("maxWorkers");
        int min_workers = (int)(long) log.get("minWorkers");
        int num_workers = (int)(long) log.get("numWorkers");
        int previous_num_workers = (int)(long) log.get("numWorkers");

        System.out.println("Current time log: " + currentLog);
        System.out.println("Request Count (Before): " + numRequests);

        // Update number of requests since last monitorization
        numRequests = numRequests + 1;

        // Check if has passed one minute since last check
        long timePassed = (long)((currentLog - lastCheck)/1000f);
        System.out.println("Time passed since last check (in seconds): " + timePassed + " seconds");
        if(timePassed >= MONITOR_PERIOD) {
            System.out.println("--------------NEW CHECK---------------------");

            // Check if it's necessary to adapt number of Workers in execution
            float ratio = (float) numRequests / timePassed;
            System.out.println("Current Ratio of Requests: " + ratio);
            if(ratio > REF + THRESHOLD && num_workers < max_workers) {
                num_workers = num_workers + 1;
            } else if (ratio < REF - THRESHOLD && num_workers > min_workers) {
                num_workers = num_workers - 1;
            }

            numRequests = 0;

            if(previous_num_workers != num_workers) {
                System.out.println("The number of workers has changed to: " + num_workers + " Workers");
                adaptVMs(num_workers);
            }
            fsOP.updateMonitorLog(COLLECTION_ID, DOCUMENT_ID, currentLog, num_workers, numRequests);


        } else {
            fsOP.updateMonitorLog(COLLECTION_ID, DOCUMENT_ID, lastCheck, num_workers, numRequests);
        }
        System.out.println("Request Count (After): " + numRequests);
        System.out.println("Current number of Workers running: " + num_workers + " Workers");
    }

    private static void adaptVMs(int nVMs) throws ExecutionException, InterruptedException, IOException {
        InstanceGroupManagersClient managersClient = InstanceGroupManagersClient.create();
        OperationFuture<Operation, Operation> result = managersClient.resizeAsync(
                "cn2122-t2-g08",
                "europe-west1-b",
                "instance-group-workers",
                nVMs
        );
        Operation oper = result.get();
        System.out.println("Resizing with status " + oper.getStatus());
    }
}
