Para que o monitor funcione, é necessário utilizar uma conta de serviço Google com as seguintes permissões:
- Cloud Datastore Owner
- Pub/Sub Admin
- Compute Engine

Para correr o monitor executar os seguintes comandos:

gcloud functions deploy funcMonitor --region=europe-west1 --entry-point=googlepubsub.Entrypoint --runtime=java11 --trigger-topic detectionworkers --source=target/deployment --service-account=<conta de serviço>