Para que o servidor funcione, é necessário utilizar uma conta de serviço Google com as seguintes permissões:
- Cloud Datastore Owner
- Pub/Sub Admin
- Storage Admin
- API

Para correr o servidor, executar os seguintes comandos:

set GOOGLE_APPLICATION_CREDENTIALS=<conta de serviço>
java -jar Worker-1.0-jar-with-dependencies.jar <nome do projeto> <nome do bucket>

----------------------------------------------------

Nota: Garantir que o nome do bucket inserido no worker é o mesmo do bucket inserido no servidor

