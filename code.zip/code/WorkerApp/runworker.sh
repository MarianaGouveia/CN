#! /bin/bash
export GOOGLE_APPLICATION_CREDENTIALS=cn2122-t2-g08-2faa845c0cec.json
java -jar Worker-1.0-jar-with-dependencies.jar cn2122-t2-g08
