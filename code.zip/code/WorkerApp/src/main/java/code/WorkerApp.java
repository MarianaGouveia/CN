package code;


import com.google.cloud.pubsub.v1.Subscriber;
import com.google.pubsub.v1.*;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class WorkerApp {


    public static String PROJECT_ID = "cn2122-t2-g08";
    public static String BUCKET_NAME = "cn-2122-t2-g08-lab4-europa";

    public static Subscriber subscribeMessages(String projectID, String subscriptionName) {

        ProjectSubscriptionName projSubscriptionName = ProjectSubscriptionName.of(
            projectID, subscriptionName);
        Subscriber subscriber =
            Subscriber.newBuilder(projSubscriptionName, new MessageReceiveHandler(BUCKET_NAME))
                .build();
        subscriber.startAsync().awaitRunning();
        return subscriber;
    }

    public static void main(String[] args) throws InterruptedException {
        if (args.length > 0) {
            PROJECT_ID = args[0];
            BUCKET_NAME = args[1];
        }
        else {
            System.out.println("pass project id as a command line argument");
            //System.exit(-1);
        }
        System.out.println("ProjectID = " + PROJECT_ID);
        System.out.println("Bucket Name = " + BUCKET_NAME);

        String subscriptionName = "workers-sub";
        String projectID = PROJECT_ID;
        Subscriber subscriber = subscribeMessages(projectID, subscriptionName);
        System.out.println("Started listening...");
        subscriber.awaitTerminated();
        /*Semaphore s = new Semaphore(0);
        s.acquire();*/

        System.out.println("Terminating...");
        //Scanner scanInput = new Scanner(System.in);
        //scanInput.next();
        //Thread.sleep(2000000);
        //Thread.currentThread().join();
    }
}
