package code;


import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;

import java.io.*;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class FireStoreOperations {

    Firestore db;
    String currentCollection;

    public void init(String pathFileKeyJson, String collectionName) throws IOException {
        GoogleCredentials credentials = null;
        if (pathFileKeyJson != null) {
            InputStream serviceAccount = new FileInputStream(pathFileKeyJson);
            credentials = GoogleCredentials.fromStream(serviceAccount);
        } else {
            // use GOOGLE_APPLICATION_CREDENTIALS environment variable
            credentials = GoogleCredentials.getApplicationDefault();
        }
        FirestoreOptions options = FirestoreOptions
                .newBuilder().setCredentials(credentials).build();
        db = options.getService();
        currentCollection=collectionName;
    }

    public void init(String pathFileKeyJson) throws IOException {
        GoogleCredentials credentials = null;
        if (pathFileKeyJson != null) {
            InputStream serviceAccount = new FileInputStream(pathFileKeyJson);
            credentials = GoogleCredentials.fromStream(serviceAccount);
        } else {
            // use GOOGLE_APPLICATION_CREDENTIALS environment variable
            credentials = GoogleCredentials.getApplicationDefault();
        }
        FirestoreOptions options = FirestoreOptions
                .newBuilder().setCredentials(credentials).build();
        db = options.getService();
        currentCollection = "Images";
    }

    public void close() throws Exception {
        db.close();
    }


    public void insertObjectsInFirestore(String blobName, List<DetectedObject> detectedObjects){

        Date date = new Date();
        System.out.println(date);

        CollectionReference colRef = db.collection("Images");
        DocumentReference docRef = colRef.document(blobName);
        CollectionReference colRefObjs = docRef.collection("objects");

        HashMap<String, Object> mapDate = new HashMap<String, Object>() {
            {
                put("date",  date);
            }
        };

        ApiFuture<WriteResult> image = docRef.create(mapDate);
        image = docRef.update(mapDate);

        for(int i = 0; i < detectedObjects.size(); i++){
            DocumentReference docRefObj = colRefObjs.document(String.valueOf(i+1));
            DetectedObject obj = detectedObjects.get(i);
            HashMap<String, Object> map = new HashMap<String, Object>() {
                {
                    put("name", obj.name);
                    put("confidence", obj.confidence);
                    for(int i = 0; i < obj.boundingBox.size(); i++){
                        put("v" + String.valueOf(i + 1), "(" + obj.boundingBox.get(i).getX() + ", " + obj.boundingBox.get(i).getY() + ")");
                    }
                }
            };

            ApiFuture<WriteResult> objects = docRefObj.create(map);
            objects = docRefObj.update(map);
        }

    }

    public void insertBlobAnnotation(String blobName, List<HashMap<String, Object>> objects) throws Exception {

        Date date = new Date();

        System.out.println("BlobName: " + blobName);
        CollectionReference colRef = db.collection("Images");
        DocumentReference docRef = colRef.document(blobName);
        CollectionReference colRefObj = docRef.collection("objects");

        HashMap<String, Object> mapDate = new HashMap<String, Object>() {
            {
                put("date",  date);
            }
        };

        ApiFuture<WriteResult> result1 = docRef.create(mapDate);
        result1 = docRef.update(mapDate);

        for(int i = 0; i < objects.size(); i++){
            DocumentReference docRefObj = colRefObj.document(String.valueOf(i+1));

            ApiFuture<WriteResult> result2 = docRefObj.create(objects.get(i));
            result2 = docRefObj.update(objects.get(i));
            System.out.println("Entrou no firestore!!");
        }

    }

}
