package code;

import com.google.cloud.vision.v1.NormalizedVertex;

import java.util.List;

public class DetectedObject {
    public String name;
    public float confidence;
    public List<NormalizedVertex> boundingBox;
}
